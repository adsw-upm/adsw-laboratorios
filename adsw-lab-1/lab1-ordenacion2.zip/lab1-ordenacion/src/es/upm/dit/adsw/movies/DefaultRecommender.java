package es.upm.dit.adsw.movies;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class DefaultRecommender implements Recommender{
	List<Movie> movies;

	public DefaultRecommender(String metadata) throws FileNotFoundException {
		this.movies = Movie.allFromFile(metadata);		
	}
	
	public DefaultRecommender(List<Movie> movies, String lang) throws FileNotFoundException {
		this.movies = movies;
		this.filterLang(lang);
		
	}
	public DefaultRecommender(String metadata, String lang) throws FileNotFoundException {
		this(metadata);
		this.filterLang(lang);
	}
	
	private void filterLang(String lang) {
		this.movies = new ArrayList<Movie>(this.movies.stream().filter(m -> m.original_language.equals(lang)).collect(Collectors.toList()));
	}
	
	
	/* Recomienda varias películas, en orden de popularidad. 
	 * 
	 * @param n número de películas a recomendar
	 * @param lang idioma de las películas
	 * @return Lista de las n películas recomendadas para el idioma lang 
	 */
	@Override
	public List<Movie> recommend(int n) {
		// CÓDIGO A IMPLEMENTAR POR EL ALUMNO		
		return null;
		// FIN CÓDIGO
	}

	/* Recomienda varias películas que tengan como idioma original el indicado, en orden de popularidad. 
	 * 
	 * @param n número de películas a recomendar
	 * @param lang idioma de las películas
	 * @return Lista de las n películas recomendadas para el idioma lang 
	 */
	@Override
	public List<Movie> recommend(int n, String lang) {
		// CÓDIGO A IMPLEMENTAR POR EL ALUMNO
		return null;
		// FIN CÓDIGO
	}


    public static void main(String[] args) throws FileNotFoundException {
    	String metadata = "data/metadata_top100.tsv";
//    	String metadata 	= "data/metadata.tsv";
    	
    	Recommender expert = new DefaultRecommender(metadata);
    	System.out.println(expert.recommend(10));
    	
    	System.out.println(expert.recommend(1, "es"));

    }


}
