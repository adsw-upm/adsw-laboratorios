package es.upm.dit.adsw.movies;

public interface MovieSorter {
	void sort(Movie[] movies);
}
