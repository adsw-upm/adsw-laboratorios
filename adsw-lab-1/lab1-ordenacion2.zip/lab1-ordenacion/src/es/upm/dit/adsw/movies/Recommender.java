package es.upm.dit.adsw.movies;

import java.util.List;

/**
 * Interfaz a implementar por los recomendadores de películas.
 * 
 * Un recomendador ha de ser capaz de recomendar una o varias películas, y filtrar las recomendaciones
 * por el idioma especificado.
 *
 */
public interface Recommender {

	/* Recomienda varias películas, en orden. 
	 * 
	 * @param n número de películas a recomendar
	 * @param lang idioma de las películas
	 * @return Lista de las n películas recomendadas para el idioma lang 
	 */
	List<Movie> recommend(int n);

	
	/*
	 * @param n número de películas a recomendar
	 * @param lang idioma de las películas
	 * @return Lista de las n películas recomendadas para el idioma lang 
	 */
	List<Movie> recommend(int n, String lang);
}
