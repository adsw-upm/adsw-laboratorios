package es.upm.dit.adsw.movies;

import java.util.Arrays;

public class DefaultSorter implements MovieSorter {

	@Override
	public void sort(Movie[] movies) {
		Arrays.sort(movies, 0, movies.length);		
	}
}
