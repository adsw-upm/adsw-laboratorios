package es.upm.dit.adsw.movies;
import java.io.File;
import java.io.FileNotFoundException;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public class Movie implements Comparable<Movie> {
    int id;
	float popularity;
    float vote_average;
    String imdb_id;
    String original_title;
    Integer budget;
    List<String> genres;
    String homepage;
    String original_language;
    String overview;
    LocalDate release_date;
    Float revenue;
    Float runtime;
    List<String> spoken_languages;
    String tagline;
    String title;
    boolean adult;
    List<String> cast;
    
    public Movie(int id,
    		float popularity,
    		float vote_average,
    		String imdb_id,
    		String original_title,
    		Integer budget,
    		String genres,
    		String homepage,
    		String original_language,
    		String overview,
    		LocalDate release_date,
    		Float revenue,
    		Float runtime,
    		String spoken_languages,
    		String tagline,
    		String title,
    		boolean adult) {
    	this.id = id;
        this.popularity = popularity;
        this.vote_average = vote_average;
        this.imdb_id = imdb_id;
        this.original_title = original_title;
        this.budget = budget;
        this.genres = Arrays.asList(genres.split(","));
        this.homepage = homepage;
        this.original_language = original_language;
        this.overview = overview;
        this.release_date = release_date;
        this.revenue = revenue;
        this.runtime = runtime;
        this.spoken_languages = Arrays.asList(spoken_languages.split(","));
        this.tagline = tagline;
        this.title = title;
        this.adult = adult;
        this.cast = new ArrayList<String>();

    }
    public static List<Movie> allFromFile(String metadata, String castfile) throws FileNotFoundException {
    	List<Movie> pelis = allFromFile(metadata);
        File cf = new File(castfile);
        try (Scanner reader = new Scanner(cf)) {
			while (reader.hasNextLine()) {
			    List<String> cast = new ArrayList<String>(Arrays.asList(reader.nextLine().split("\t")));
			    int movieid = Integer.parseInt(cast.remove(0));
			    for(Movie peli: pelis) {
			    	if(peli.id == movieid) {
			    		peli.setCast(cast);
			    		break;
			    	}
			    }
			    
			}
		}
        return pelis;
    }    
    
    public static ArrayList<Movie> allFromFile(String metadata) throws FileNotFoundException {
    	int wrong = 0;
    	int right = 0;
    	ArrayList<Movie> pelis = new ArrayList();
            File meta = new File(metadata);
            Scanner reader = new Scanner(meta);
            List<String> header = Arrays.asList(reader.nextLine().split("\t"));
            Map<String, Integer> fields = new HashMap<String, Integer>();
            
            for(int i=0; i<header.size(); i++) {
            	fields.put(header.get(i), i);
            }
            
            while (reader.hasNextLine()) {
                String[] data = reader.nextLine().split("\t");
                if(data.length < 1) {
                	continue;
                }
                try { 
	              Movie peli = new Movie(
	            		  Integer.parseInt(data[fields.get("id")]),
	            		  Float.parseFloat(data[fields.get("popularity")]),
	            		  Float.parseFloat(data[fields.get("vote_average")]),
	            		  data[fields.get("imdb_id")],
	            		  data[fields.get("original_title")],
	            		  Integer.parseInt(data[fields.get("budget")]),
	            		  data[fields.get("genres")],
	            		  data[fields.get("homepage")],
	            		  data[fields.get("original_language")],
	            		  data[fields.get("overview")],
	            		  LocalDate.parse(data[fields.get("release_date")]),
	            		  Float.parseFloat(data[fields.get("revenue")]),
	            		  Float.parseFloat(data[fields.get("runtime")]),
	            		  data[fields.get("spoken_languages")],
	            		  data[fields.get("tagline")],
	            		  data[fields.get("title")],
	            		  data[fields.get("adult")] == "True");
	              pelis.add(peli);
                } catch(ArrayIndexOutOfBoundsException e) {
                	System.out.println("Unknown field: " + e.getMessage());
                	wrong++;
                	continue;      
                } catch(NumberFormatException e) {
                	System.out.println(String.join(" ", data));
                	System.out.println("Badly formatted number: " + e.getMessage());
                	wrong++;
                	continue;
                } catch( java.time.format.DateTimeParseException e) {
                	System.out.println("Bad date: " + e.getMessage());
                	wrong++;
                	continue;	
                }
                right++;
            }
            reader.close();
            System.out.println("Imported: " + right + "/" + (right + wrong));
    	return pelis;
    }
    
    public void setCast(List<String> cast){
    	this.cast = cast;
    }    
    
    public void addActor(String name){
    	this.cast.add(name);
    }    
    
    public String toString(){
    	return this.title + " (" + this.original_title + ") [" + this.popularity + "]";
    }

	@Override
	public int compareTo(Movie other) {
		// CÓDIGO DEL ALUMNO
		return 0;
		// FIN CÓDIGO
	}
}
