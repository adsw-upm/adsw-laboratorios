package es.upm.dit.adsw.movies;

import static org.junit.jupiter.api.Assertions.*;

import java.io.FileNotFoundException;
import java.util.List;

import org.junit.jupiter.api.Test;


class MovieTester {


}
