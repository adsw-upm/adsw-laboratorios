package es.upm.dit.adsw.lab1;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.FileNotFoundException;
import java.text.ParseException;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.MethodOrderer.MethodName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import es.upm.dit.adsw.geosocial.Localizacion;
import es.upm.dit.adsw.geosocial.Usuario;

@TestMethodOrder(MethodName.class)
class TestsFuncionales {
	/**
	 * Comprueba que se puede crear un AlmacenLab1
	 * @throws FileNotFoundException
	 * @throws ParseException
	 */
	@SuppressWarnings("unused")
	@Test
	void test1Constructor() throws FileNotFoundException, ParseException {
		AlmacenLab1 almacen1 = new AlmacenLab1(Arrays.asList(new Usuario(0), new Usuario(1)));
		assertEquals(2, almacen1.getNUsuarios());
		AlmacenLab1 casting = almacen1; // Esto fallará si no se implementa el interfaz
	}
	
	/**
	 * Comprueba que se puede crear un AlmacenLab1 desde un fichero de localizaciones
	 */
	@Test
	void test2ConstructorFichero() throws FileNotFoundException, ParseException {
		AlmacenLab1 ranked = new AlmacenLab1("data/locations10.tsv");
		assertEquals(10, ranked.getNUsuarios());
		assertEquals(1392, ranked.getNRegistros());
	}
	/**
	 * Comprueba que un caso sencillo de coincidencia funciona.
	 * Se añaden tres usuarios, dos de ellos tienen una coincidencia.
	 * @throws FileNotFoundException
	 * @throws ParseException
	 */
	@Test
	void test3CoincidentesManual() throws FileNotFoundException, ParseException {
		Usuario u1 = new Usuario(1);
		Usuario u2 = new Usuario(2);
		Usuario u3 = new Usuario(3);
		u1.registrar(new Localizacion(10, 0));
		u2.registrar(new Localizacion(10, 0));
		AlmacenLab1 gestor = new AlmacenLab1(Arrays.asList(u1, u2, u3));
		Set<Integer> coinciden = gestor.buscarCoincidencias(u1.getId());
		assertEquals(1, coinciden.size());
		coinciden = gestor.buscarCoincidencias(u2.getId());
		assertEquals(1, coinciden.size());
		assertEquals(0, gestor.buscarCoincidencias(u3.getId()).size());
	}
	
	/**
	 * Comprueba que tres casos de los que sabemos el resultado esperado funcionan.
	 * 
	 * @throws FileNotFoundException
	 * @throws ParseException
	 */
	@Test
	void test4Coincidentes() throws FileNotFoundException, ParseException {
		AlmacenLab1 ranked = new AlmacenLab1("data/locations10.tsv");
		assertEquals(1, ranked.buscarCoincidencias(5496).size());
		assertEquals(0, ranked.buscarCoincidencias(42).size());
		assertEquals(1, ranked.buscarCoincidencias(4223).size());
	}
	
	/**
	 * Comprueba que getUltimos funciona para un caso simple: 3 usuarios y 3 tiempos diferentes.
	 * 
	 * @throws FileNotFoundException
	 * @throws ParseException
	 */
	@Test
	void test5UltimosManual() throws FileNotFoundException, ParseException {
		Usuario u1 = new Usuario(1);
		Usuario u2 = new Usuario(2);
		Usuario u3 = new Usuario(3);
		u2.registrar(new Localizacion(0, 0), LocalDateTime.now());
		// u1 tiene un registro ligeramente más nuevo. Debería ir antes
		u1.registrar(new Localizacion(0, 0), LocalDateTime.now().plusMinutes(1));
		AlmacenLab1 g1 = new AlmacenLab1(Arrays.asList(u1, u2, u3));
		
		assertEquals(1, g1.getUltimos(3).get(0));
		assertEquals(2, g1.getUltimos(3).get(1));
		// Si un usuario no tiene registros, no aparecerá entre los últimos.
		assertEquals(2, g1.getUltimos(3).size());
	}
	
	/**
	 * Comprueba que getUltimos funciona para el conjunto pequeño.
	 * 
	 * @throws FileNotFoundException
	 * @throws ParseException
	 */
	@Test
	void test6Ultimos() throws FileNotFoundException, ParseException {
		AlmacenLab1 ranked = new AlmacenLab1("data/locations10.tsv");
		List<Integer> top = ranked.getUltimos(10);
		assertEquals(top.size(), 10);
		for(int i=1; i<top.size(); i++) {
			LocalDateTime t1 = ranked.getUsuario(top.get(i-1)).getUltimo().getFecha();
			LocalDateTime t2 = ranked.getUsuario(top.get(i)).getUltimo().getFecha();
			assert(t1.compareTo(t2) >= 0);
		}
		LocalDateTime masReciente = ranked.getUsuario(top.get(0)).getUltimo().getFecha();
		for(Usuario u: ranked.getUsuarios()) {
			// Ningún usuario tiene un registro más reciente
			assert(!u.getUltimo().getFecha().isAfter(masReciente));
		}
	}
	
	/**
	 * Comprueba que el método buscarUsuariosPorTiempo funciona para un caso simple, con 3 usuarios, y 3 tiempos diferentes.
	 * @throws FileNotFoundException
	 * @throws ParseException
	 */
	@Test
	void test7BusquedaTiempoManual() throws FileNotFoundException, ParseException {
		Usuario u1 = new Usuario(1);
		Usuario u2 = new Usuario(2);
		Usuario u3 = new Usuario(3);
		Localizacion loc1 = new Localizacion(0, 100);
		Localizacion loc2 = new Localizacion(100, 0);
		LocalDateTime ahora = LocalDateTime.now();
		LocalDateTime en1 = ahora.plusMinutes(1);
		LocalDateTime en2 = ahora.plusMinutes(2);
		LocalDateTime en15 = ahora.plusMinutes(15);
		LocalDateTime en5 = ahora.plusMinutes(5);
		
		u1.registrar(loc1, ahora);
		
		u2.registrar(loc1, en1);
		u2.registrar(loc1, en5);

		u3.registrar(loc2, en2);
		u3.registrar(loc1, en15);

		Lab1Interface servicio = new AlmacenLab1(Arrays.asList(u1, u2, u3));
		List<Integer> listaAhora = servicio.buscarUsuariosPorTiempo(ahora, 5);
		List<Integer> listaEn1 = servicio.buscarUsuariosPorTiempo(en1, 5);
		List<Integer> listaEn5 = servicio.buscarUsuariosPorTiempo(en5, 5);
		List<Integer> listaEn15 = servicio.buscarUsuariosPorTiempo(en15, 5);
		
		assertEquals(Arrays.asList(u1.getId(), u2.getId(), u3.getId()), listaAhora);
		assertEquals(3, listaEn1.size());
		assertEquals(2, listaEn5.size());
		assertEquals(1, listaEn15.size());
	}
	
}
