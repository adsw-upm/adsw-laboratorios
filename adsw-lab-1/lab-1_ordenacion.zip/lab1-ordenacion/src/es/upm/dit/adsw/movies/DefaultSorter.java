package es.upm.dit.adsw.movies;

import java.util.Arrays;

/**
 * Clase que permite ordenar una lista de películas utilizando el método por defecto de comparación.
 * Es decir, utiliza el método {@link es.upm.dit.adsw.movies#compareTo}.
 *  
 */
public class DefaultSorter implements MovieSorter {

	/**
	 * Ordena el array de películas.
	 */
	public void sort(Movie[] movies) {
		//CÓDIGO A IMPLEMENTAR POR EL ALUMNO
		//FIN DEL CÓDIGO/
	}
}
