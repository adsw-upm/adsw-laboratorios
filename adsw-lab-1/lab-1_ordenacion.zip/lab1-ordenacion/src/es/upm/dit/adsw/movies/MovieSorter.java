package es.upm.dit.adsw.movies;

/**
 * Interfaz para implementar clases de ordenación de arrays de películas.
 *
 */
public interface MovieSorter {
	/**
	 * Ordena el array de películas proporcionado
	 * @param movies Array a ordenar
	 */
	void sort(Movie[] movies);
}
