package es.upm.dit.adsw.movies;

import static org.junit.jupiter.api.Assertions.*;

import java.io.FileNotFoundException;
import java.util.List;

import org.junit.jupiter.api.Test;


/**
 * Conjunto de pruebas para las clases del paquete es.upm.dit.adsw.movies
 *
 */
class MovieTester {

	@Test
	void testLoadAll() throws FileNotFoundException {
		//CÓDIGO A IMPLEMENTAR POR EL ALUMNO
		return;
		//FIN DEL CÓDIGO
	}
	
	@Test
	void testRecommend() throws FileNotFoundException {
		//CÓDIGO A IMPLEMENTAR POR EL ALUMNO
		return;
		//FIN DEL CÓDIGO
	}

}
