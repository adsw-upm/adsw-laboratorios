package es.upm.dit.adsw.movies;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Implementación de referencia del recomendador de películas.
 * 
 * Los métodos de recomendación utilizan la popularidad como criterio, devolviendo las películas con
 * mayor popularidad primero.
 *
 */
public class DefaultRecommender implements Recommender{
	List<Movie> movies;

	public DefaultRecommender(String metadata) throws FileNotFoundException {
		this.movies = Movie.allFromFile(metadata);		
	}
	
	public DefaultRecommender(List<Movie> movies, String lang) throws FileNotFoundException {
		this.movies = movies;
		this.filterLang(lang);
		
	}
	public DefaultRecommender(String metadata, String lang) throws FileNotFoundException {
		this(metadata);
		this.filterLang(lang);
	}
	
	private void filterLang(String lang) {
		this.movies = new ArrayList<Movie>(this.movies.stream().filter(m -> m.original_language.equals(lang)).collect(Collectors.toList()));
	}
	
	
	// Helper para mi solución. Esto tampoco lo ven los alumnos.
	private List<Movie> recommend(int n, Stream<Movie> movies) {
		
		List<Movie> rec = new ArrayList<Movie>();
		Movie[] pelis = movies.toArray(Movie[]::new);
		// Idealmente se debería poder filtrar y devolver el top N
		// pero no conozco el método de Java para calcular el top.
		while(rec.size() < n) {
			Movie max = null;
			for(Movie movie: pelis) {
				if(rec.contains(movie)) {
					continue;
				}
				if(max == null || movie.compareTo(max) > 0) {
					max = movie;
				}

			}
			if(max == null ) {
				break;
			}
			rec.add(max);
		}
		return rec;
	}
	
	/* Recomienda varias películas, en orden de popularidad. 
	 * 
	 * @param n número de películas a recomendar
	 * @param lang idioma de las películas
	 * @return Lista de las n películas recomendadas para el idioma lang 
	 */
	@Override
	public List<Movie> recommend(int n) {
		//CÓDIGO A IMPLEMENTAR POR EL ALUMNO
		return new ArrayList<Movie>();
		//FIN DEL CÓDIGO
	}

	/* Recomienda varias películas que tengan como idioma original el indicado, en orden de popularidad. 
	 * 
	 * @param n número de películas a recomendar
	 * @param lang idioma de las películas
	 * @return Lista de las n películas recomendadas para el idioma lang 
	 */
	@Override
	public List<Movie> recommend(int n, String lang) {
		//CÓDIGO A IMPLEMENTAR POR EL ALUMNO
		return new ArrayList<Movie>();
		//FIN DEL CÓDIGO
	}


    public static void main(String[] args) throws FileNotFoundException {
    	String metadata = "data/metadata_top100.tsv";
    	
//    	String metadata 	= "data/metadata.tsv"; // Descomentar para usar el dataset completo
    	
    	Recommender expert = new DefaultRecommender(metadata);
    	System.out.println(expert.recommend(10));
    	
    	System.out.println(expert.recommend(1, "es"));

    }


}
