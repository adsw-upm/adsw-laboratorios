package es.upm.dit.adsw.lab2;

import es.upm.dit.adsw.geosocial.*;

/**
 * 
 * La interfaz Diccionario define un conjunto de métodos para trabajar con una
 * estructura de datos de diccionario que asocia una clave entera con un objeto
 * Usuario.
 */
public interface Diccionario {

	/**
	 * 
	 * Agrega un objeto Usuario al diccionario, asociándolo con la clave
	 * especificada.
	 * 
	 * @param clave   la clave entera con la que se desea asociar el objeto Usuario
	 * @param usuario el objeto Usuario que se desea agregar al diccionario
	 */
	void put(Integer clave, Usuario usuario);

	/**
	 * 
	 * Retorna el objeto Usuario asociado con la clave especificada.
	 * 
	 * @param clave la clave entera con la que se desea buscar el objeto Usuario
	 * @return el objeto Usuario asociado con la clave especificada, o null si no
	 *         existe una asociación para esa clave
	 */
	Usuario get(Integer clave);

	/**
	 * 
	 * Elimina del diccionario la asociación de clave y objeto Usuario especificada.
	 * 
	 * @param clave la clave entera de la asociación que se desea remover
	 * @return el objeto Usuario que estaba asociado con la clave especificada, o
	 *         null si no exist�a una asociación para esa clave
	 */
	Object remove(Integer clave);

	/**
	 * 
	 * Retorna el número de elementos en el diccionario.
	 * 
	 * @return el número de elementos en el diccionario
	 */
	int size();

	/**
	 * 
	 * Elimina todas las asociaciones de clave y objeto Usuario del diccionario.
	 */
	void clear();
}