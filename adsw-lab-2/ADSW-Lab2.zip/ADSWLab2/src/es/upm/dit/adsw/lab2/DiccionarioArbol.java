/**

Clase que representa un árbol binario de búsqueda que implementa la interfaz Diccionario.
Esta clase permite insertar, buscar, eliminar y conocer el número de elementos del árbol.
El árbol está formado por nodos de la clase Nodo, que contienen cada uno un objeto de la clase CV.
Los nodos están organizados de forma que cada nodo tiene dos hijos, uno izquierdo y otro derecho, y los nodos
del subárbol izquierdo tienen claves menores que la del nodo padre, mientras que los nodos del subárbol derecho
tienen claves mayores.
*/
package es.upm.dit.adsw.lab2;

import java.util.ArrayList;
import java.util.List;
import es.upm.dit.adsw.geosocial.*;

public class DiccionarioArbol implements Diccionario {
	private Nodo raiz;

	/**
	 * Constructor de la clase Arbol que inicializa la raíz a null.
	 */
	public DiccionarioArbol() {
		raiz = null;
	}

	/**
	 * Método recursivo para insertar un objeto CV en el árbol usando búsqueda
	 * binaria y recursión. Si la clave ya existe, se actualiza el valor.
	 * 
	 * @param nodo El nodo en el que se desea insertar el objeto CV.
	 * @param cv   El objeto CV que se desea insertar.
	 */
	private void put(Nodo nodo, CV cv) {
		// TODO Debes hacer este método si decides hacerlo recursivamente en el laboratorio 2
	}

	/**
	 * Método para insertar un nuevo objeto CV en la raíz del árbol. Si queremos
	 * hacerlo de forma recursiva debe llamar a "void put(Nodo nodo, CV cv)" con la
	 * raíz del árbol si no es null Y si es null crear un nuevo nodo.
	 * 
	 * @param clave La clave del objeto CV que se desea insertar.
	 * @param usu   El usuario del objeto CV que se desea insertar.
	 */
	@Override
	public void put(Integer clave, Usuario usu) {
		// TODO Debes hacer este método para el laboratorio 2	
		}

	/**
	 * Método para obtener el valor de una clave usando búsqueda binaria y
	 * recursión.
	 * 
	 * @param nodo  El nodo a partir del cual se comienza a buscar el valor.
	 * @param clave La clave del valor que se desea buscar.
	 * @return El usuario correspondiente a la clave buscada, o null si la clave no
	 *         se encuentra en el árbol.
	 */
	private Usuario get(Nodo nodo, int clave) {
		// TODO Debes hacer este método si decides hacerlo recursivamente en el laboratorio 2
		return null;
	}

	/**
	 * 
	 * Devuelve el usuario asociado a la clave especificada en el árbol. Si queremos
	 * hacerlo de forma recursiva debe llamar "Usuario get(Nodo nodo, int clave)"
	 * con la raíz del árbol.
	 * 
	 * @param clave La clave del usuario que se desea buscar.
	 * @return El usuario asociado a la clave especificada si se encuentra en el
	 *         árbol; de lo contrario, devuelve null.
	 */
	@Override
	public Usuario get(Integer clave) {
		// TODO Debes hacer este método para el laboratorio 2
		return null;
	}

	/**
	 * 
	 * Método para eliminar un objeto CV por la clave de un árbol binario de
	 * búsqueda utilizando recursividad. Si queremos hacerlo de forma recursiva debe
	 * llamar a "Nodo remove(Nodo nodo, int clave)" con la raíz del árbol.
	 * 
	 * 
	 * @param clave la clave del objeto CV a eliminar
	 * @return el nodo padre del nodo que contiene el objeto CV eliminado, o null si
	 *         la clave no fue encontrada
	 */
	@Override
	public Nodo remove(Integer clave) {
		// NO IMPLEMENTAR HASTA LA PRÁCTICA 2
		return null;
	}

	/**
	 * 
	 * Método para eliminar un objeto CV por la clave de un árbol binario de
	 * búsqueda utilizando recursión. Si la clave no se encuentra, devuelve null.
	 * 
	 * @param nodo  El nodo a partir del cual se buscará el objeto a eliminar.
	 * @param clave La clave del objeto CV a eliminar.
	 * @return el nodo padre del nodo que contiene el objeto CV eliminado, o null si
	 *         la clave no fue encontrada
	 */
	private Nodo remove(Nodo nodo, int clave) {
		// NO IMPLEMENTAR HASTA LA PRÁCTICA 2
		return null;
		}

	/**
	 * 
	 * Devuelve el número de objetos CV en el árbol utilizando el algoritmo de
	 * búsqueda binaria mediante recursión. Si queremos hacerlo de forma recursiva
	 * debe llamar a "int size(Nodo nodo)" con la raíz del árbol.
	 * 
	 * @return El número de objetos CV en el árbol.
	 */
	@Override
	public int size() {
		// TODO Debes hacer este método para el laboratorio 2
		return 0;
	}

	/**
	 * 
	 * Método que devuelve el número de objetos CV en el árbol utilizando el árbol
	 * binario de búsqueda mediante recursión.
	 * 
	 * @param nodo El nodo raíz del subárbol actual.
	 * @return El número de objetos CV en el árbol.
	 */
	private int size(Nodo nodo) {
		// TODO Debes hacer este método si decides hacerlo recursivamente en el laboratorio 2
		return 0;
	}

	/**
	 * 
	 * Elimina todos los objetos CV del árbol binario de búsqueda mediante
	 * recursión. La raíz del árbol se establece en null.
	 */
	@Override
	public void clear() {
		// TODO Debes hacer este método para el laboratorio 2
	}

	/**
	 * 
	 * Método para dibujar el árbol. Se utiliza para visualizar la estructura del
	 * árbol de una manera gráfica.
	 * 
	 * @param nodo  El nodo raíz del árbol a dibujar.
	 * @param nivel El nivel de profundidad del nodo actual. Usado para posicionar
	 *              correctamente los nodos en la impresión.
	 */
	public void draw() {
		draw(raiz, 0);
	}

	/**
	 * 
	 * Método para dibujar verticalmente el árbol usando arte ASCII con líneas que
	 * conectan los nodos.
	 * 
	 * @param nodo el nodo actual a dibujar
	 */
	private void draw(Nodo nodo, int nivel) {
		if (nodo != null) {
			draw(nodo.getHijoDerecho(), nivel + 1);
			for (int i = 0; i < nivel; i++) {
				System.out.print(" ");
			}
			System.out.println(nodo.getCv().getClave());
			draw(nodo.getHijoIzquierdo(), nivel + 1);
		}
	}


}