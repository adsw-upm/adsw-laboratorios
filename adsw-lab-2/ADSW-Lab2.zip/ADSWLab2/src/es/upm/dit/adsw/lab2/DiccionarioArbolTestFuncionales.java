/**

Clase de pruebas para la clase Arbol.
*/
package es.upm.dit.adsw.lab2;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import es.upm.dit.adsw.geosocial.*;

class DiccionarioArbolTestFuncionales {

	private DiccionarioArbol arbol;

	/**

	Inicializa el árbol para los tests.
	*/
	@BeforeEach
	void setUp() {
		arbol = new DiccionarioArbol();
	}

	/**

	Prueba los métodos put() y get() de la clase Arbol.
	*/
	@Test
	void testPutAndGet() {
		Usuario usu1 = new Usuario(1);
		Usuario usu2 = new Usuario(2);
		Usuario usu3 = new Usuario(3);
		arbol.put(usu1.getId(), usu1);
		arbol.put(usu2.getId(), usu2);
		arbol.put(usu3.getId(), usu3);
		assertEquals(usu1, arbol.get(1));
		assertEquals(usu2, arbol.get(2));
		assertEquals(usu3, arbol.get(3));
	}

	/**

	Prueba el método remove() de la clase Arbol.
	*/
	@Test
	void testRemove() {
		Usuario usu1 = new Usuario(1);
		Usuario usu2 = new Usuario(2);
		Usuario usu3 = new Usuario(3);
		arbol.put(usu1.getId(), usu1);
		arbol.put(usu2.getId(), usu2);
		arbol.put(usu3.getId(), usu3);
		assertEquals(usu1, (arbol.remove(2)).getCv().getUsuario());
		assertNull(arbol.get(2));
		assertEquals(2, arbol.size());
		assertEquals(usu1, (arbol.remove(3)).getCv().getUsuario());
		assertNull(arbol.get(3));
		assertEquals(1, arbol.size());
		assertNull((arbol.remove(1)));
	}

	/**

	Prueba el método size() de la clase Arbol.
	*/
	@Test
	void testSize() {
		assertEquals(0, arbol.size());
		Usuario usu1 = new Usuario(1);
		Usuario usu2 = new Usuario(2);
		Usuario usu3 = new Usuario(3);
		arbol.put(usu1.getId(), usu1);
		arbol.put(usu2.getId(), usu2);
		arbol.put(usu3.getId(), usu3);
		assertEquals(3, arbol.size());
	}

	/**

	Prueba el método clear() de la clase Arbol.
	*/
	@Test
	void testClear() {
		Usuario usu1 = new Usuario(1);
		Usuario usu2 = new Usuario(2);
		Usuario usu3 = new Usuario(3);
		arbol.put(usu1.getId(), usu1);
		arbol.put(usu2.getId(), usu2);
		arbol.put(usu3.getId(), usu3);
		arbol.clear();
		assertEquals(0, arbol.size());
		assertNull(arbol.get(1));
		assertNull(arbol.get(2));
		assertNull(arbol.get(3));
	}

	/**

	Prueba los métodos put() y get() de la clase Arbol y el comportamiento
	de put() cuando se actualiza un valor.
	*/
	@Test
	void testPutAndGetUpdateValue() {
		Usuario usu1 = new Usuario(1);
		Usuario usu2 = new Usuario(2);
		Usuario usu3 = new Usuario(3);
		Usuario usu11 = new Usuario(11);
		Usuario usu22 = new Usuario(22);
		Usuario usu33 = new Usuario(33);
		arbol.put(1, usu1);
		arbol.put(2, usu2);
		arbol.put(3, usu3);
		arbol.put(1, usu11);
		arbol.put(2, usu22);
		arbol.put(3, usu33);
		assertEquals(usu11, arbol.get(1));
		assertEquals(usu22, arbol.get(2));
		assertEquals(usu33, arbol.get(3));
	}

	

}
