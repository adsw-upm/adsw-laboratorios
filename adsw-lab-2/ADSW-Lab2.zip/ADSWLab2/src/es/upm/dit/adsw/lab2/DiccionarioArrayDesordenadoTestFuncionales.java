/**

La clase ArrayDesordenadoTestFuncionales contiene métodos de prueba para comprobar
el correcto funcionamiento de la clase ArrayDesordenado. Esta clase se encarga de
probar los métodos put, get, remove, size y clear de la clase ArrayDesordenado.
*/
package es.upm.dit.adsw.lab2;

import es.upm.dit.adsw.geosocial.*;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

// TODO: implement the tests

class DiccionarioArrayDesordenadoTestFuncionales {

	private DiccionarioArrayDesordenado diccionario;

	/**
	 * Configura el entorno de prueba.
	 * 
	 * @throws Exception
	 */
	@BeforeEach
	void setUp() throws Exception {
		this.diccionario = new DiccionarioArrayDesordenado(10);
	}

	/**
	 * Comprueba el método put de la clase ArrayDesordenado.
	 */
	@Test
	void testPut() {
		Usuario usu1 = new Usuario(1);
		Usuario usu2 = new Usuario(2);
		Usuario usu3 = new Usuario(3);

		diccionario.put(usu1.getId(), usu1);
		assertEquals(usu1, diccionario.get(1));
		diccionario.put(usu2.getId(), usu2);
		assertEquals(usu2, diccionario.get(2));
		diccionario.put(usu3.getId(), usu3);
		assertEquals(usu3, diccionario.get(3));
	}

	/**
	 * Comprueba el método get de la clase ArrayDesordenado.
	 */
	@Test
	void testGet() {
		Usuario usu1 = new Usuario(1);
		Usuario usu2 = new Usuario(2);
		Usuario usu3 = new Usuario(3);

		DiccionarioArrayDesordenado diccionario = new DiccionarioArrayDesordenado(10);
		diccionario.put(usu1.getId(), usu1);
		assertEquals(usu1, diccionario.get(1));
		assertNull(diccionario.get(2));
		diccionario.put(usu2.getId(), usu2);
		assertEquals(usu2, diccionario.get(2));
		diccionario.put(1, usu3);
		assertEquals(usu3, diccionario.get(1));
	}

	/**
	 * Comprueba el método remove de la clase ArrayDesordenado.
	 */
	@Test
	void testRemove() {
		DiccionarioArrayDesordenado diccionario = new DiccionarioArrayDesordenado(10);
		Usuario usu1 = new Usuario(1);
		Usuario usu2 = new Usuario(2);
		Usuario usu3 = new Usuario(3);
		diccionario.put(usu1.getId(), usu1);
		diccionario.put(usu2.getId(), usu2);
		diccionario.put(usu3.getId(), usu3);
		Object removedValue = diccionario.remove(2);
		assertEquals(usu2, removedValue);
		assertNull(diccionario.get(2));
		assertEquals(2, diccionario.size());
	}

	/**
	 * Comprueba el método size de la clase ArrayDesordenado.
	 */
	@Test
	void testSize() {
		DiccionarioArrayDesordenado diccionario = new DiccionarioArrayDesordenado(10);
		Usuario usu1 = new Usuario(1);
		Usuario usu2 = new Usuario(2);

		assertEquals(0, diccionario.size());
		diccionario.put(usu1.getId(), usu1);
		assertEquals(1, diccionario.size());
		diccionario.put(usu2.getId(), usu2);
		assertEquals(2, diccionario.size());
		diccionario.remove(1);
		assertEquals(1, diccionario.size());
	}

	/**
	 * Comprueba el método clear de la clase ArrayDesordenado.
	 */
	@Test
	void testClear() {
		DiccionarioArrayDesordenado diccionario = new DiccionarioArrayDesordenado(10);
		Usuario usu1 = new Usuario(1);
		Usuario usu2 = new Usuario(2);
		diccionario.put(usu1.getId(), usu1);
		diccionario.put(usu2.getId(), usu2);
		diccionario.clear();
		assertEquals(0, diccionario.size());
		assertNull(diccionario.get(1));
		assertNull(diccionario.get(2));
	}

}
