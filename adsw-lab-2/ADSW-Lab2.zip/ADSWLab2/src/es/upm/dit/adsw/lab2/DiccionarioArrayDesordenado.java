/**

Esta clase implementa la interfaz Diccionario para crear un diccionario de
ClaveValor almacenado en un array desordenado.
*/
package es.upm.dit.adsw.lab2;
import es.upm.dit.adsw.geosocial.*;
public class DiccionarioArrayDesordenado implements Diccionario {
	private CV[] datos;
	private int ultimo;

	/**
	 * Constructor de la clase ArrayDesordenado. Crea un array de ClaveValor de tama�o "tamano"
	 * y establece el valor del último elemento como 0.
	 * 
	 * @param tamano Tamaño del array que se quiere crear.
	 */
	public DiccionarioArrayDesordenado(int tamano){
	    datos = new CV[tamano];
	    ultimo = 0;
	}

	/**
	 * A�ade una entrada al diccionario con una clave y un usuario. Si la clave ya existe, 
	 * se actualiza el valor del usuario asociado a dicha clave.
	 * 
	 * @param clave Clave que se quiere añadir o actualizar.
	 * @param usu Usuario asociado a la clave que se quiere añadir o actualizar.
	 */
	@Override
	public void put(Integer clave, Usuario usu) {
	    for(int i = 0; i < ultimo; i++){
	        if(datos[i].getClave()==clave){
	            datos[i].setUsuario(usu);
	            return;
	        }
	    }
	    datos[ultimo] = new CV(clave, usu);
	    ultimo++;
	}

	/**
	 * Obtiene el usuario asociado a una clave dada. Si la clave no existe en el diccionario,
	 * devuelve null.
	 * 
	 * @param clave Clave cuyo usuario se quiere obtener.
	 * @return Usuario asociado a la clave dada o null si la clave no existe en el diccionario.
	 */
	@Override
	public Usuario get(Integer clave) {
	    for(int i = 0; i < ultimo; i++){
	        if(datos[i].getClave()== clave){
	            return datos[i].getUsuario();
	        }
	    }
	    return null;    
	}

	/**
	 * Elimina una entrada del diccionario dada una clave. Si la clave no existe en el diccionario,
	 * devuelve null.
	 * 
	 * @param clave Clave que se quiere eliminar del diccionario.
	 * @return Usuario asociado a la clave eliminada o null si la clave no existe en el diccionario.
	 */
	@Override
	public Object remove(Integer clave) {
	    for(int i = 0; i < ultimo; i++){
	        if(datos[i].getClave()==clave){
	            Object valor = datos[i].getUsuario();
	            for(int j = i; j < ultimo; j++){
	                datos[j] = datos[j+1];
	            }
	            ultimo--;
	            return valor;
	        }
	    }
	    return null;
	}

	/**
	 * Devuelve el número de elementos del diccionario.
	 * 
	 * @return Número de elementos del diccionario.
	 */
	@Override
	public int size() {
	    return ultimo;
	}

	/**
	 * Elimina todos los elementos del diccionario estableciendo el valor del último elemento en 0.
	 */
	@Override
	public void clear() {
	    ultimo = 0;
	}
}