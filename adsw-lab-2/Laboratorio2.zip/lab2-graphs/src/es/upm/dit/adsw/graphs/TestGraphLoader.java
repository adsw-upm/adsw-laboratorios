package es.upm.dit.adsw.graphs;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import edu.princeton.cs.algs4.DirectedEdge;
import edu.princeton.cs.algs4.EdgeWeightedDigraph;
import es.upm.dit.adsw.movies.Movie;

public class TestGraphLoader {

	private GraphLoader loader;
	private static List<Movie> pelis;
	private static int nActors = 0;

	@BeforeAll
	public static void setUpAll() throws IOException {
		pelis = Movie.allFromFile("data/metadata.tsv", "data/cast.tsv");
		nActors = (int) GraphLoader.actorsCount("data/cast.tsv");
	}

	@BeforeEach
	public void setUp() {
		loader = new GraphLoader();
	}

	@Test
	public void test_getActorID() {

		// Probamos que al obtener el id de un actor que no existe en el diccionario le asigna el id 0
		assertEquals(0, loader.getActorID("Antonio Banderas"));
		// Probamos que al obtener el id de un actor que si existe en el diccionario nos devuelve su id
		assertEquals(0, loader.getActorID("Antonio Banderas"));

		// Probamos que los ids que se asignan son enteros consecutivos
		assertEquals(1, loader.getActorID("Bruce Willis"));
		assertEquals(2, loader.getActorID("Samuel L Jackson"));

		// Probamos que al obtener el id de un actor que si existe en el diccionario, 
		// despues de haber añadido varios, nos devuelve su id
		assertEquals(1, loader.getActorID("Bruce Willis"));

	}

	@Test
	public void test_addEdge() {
		// Definimos dos actores y una pelicula de prueba
		String actor1 = "Samuel L Jackson";
		String actor2 = "Bruce Willis";
		Movie movie = new Movie(0, 0, 0, null, "Pulp Fiction", null, "", null,
				null, null, null, null, null, "", null, "Pulp Fiction", true);

		// Inicializamos el grafo
		loader.g = new EdgeWeightedDigraph(2);

		// Probamos que el grafo no tiene aristas 
		assertEquals(0, loader.g.E());

		// Creamos la arista entre los dos actores
		loader.addEdge(actor1, actor2, movie);

		// Comprobamos que hay 2 aristas en el grafo
		assertEquals(2, loader.g.E());

		// Probamos que los actores están adyacentes después de crear la arista
		Iterator<DirectedEdge> edges = loader.g.adj(loader.getActorID(actor1)).iterator();
		assertEquals(loader.getActorID(actor2), edges.next().to());

		edges = loader.g.adj(loader.getActorID(actor2)).iterator();
		assertEquals(loader.getActorID(actor1), edges.next().to());
	}

	@Test
	public void test_getActorPairs() {

		// Inicializamos el grafo
		loader.g = new EdgeWeightedDigraph(nActors);

		// Sacamos la pelicula de los vengadores de la lista
		Movie movie = pelis.get(17789);
		// En esta película aparecen 115 actores, por lo que habrá (115*114)/2=6555 parejas
		List<String[]> parejas = loader.getActorsPairs(movie);
		assertEquals(6555, parejas.size());

	}

	@Test
	public void test_getActorPairsOnEmptyCast() {
		// Inicializamos el grafo
		loader.g = new EdgeWeightedDigraph(nActors);
		// Definimos una pelicula de prueba con un solo actor
		String actor1 = "Samuel L Jackson";
		Movie movie = new Movie(0, 0, 0, null, "Pulp Fiction", null, "", null,
				null, null, null, null, null, "", null, "Pulp Fiction", true);
		movie.cast.add(actor1);
		List<String[]> parejas = loader.getActorsPairs(movie);
		assertEquals(0, parejas.size());
	}

	@Test
	public void test_loadGraph() {
		// Inicializamos el grafo
		loader.loadGraph(pelis, nActors);

		// Comprobamos que se cargan todas las aristas
		assertEquals(13008420, loader.g.E());
		
		// Comprobamos que se cargan todos los actores
		assertEquals(201808, loader.actorsMap.size());
		
	}

}
