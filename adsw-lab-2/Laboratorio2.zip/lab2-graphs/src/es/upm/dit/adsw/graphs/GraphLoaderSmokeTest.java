package es.upm.dit.adsw.graphs;

import java.util.List;

import edu.princeton.cs.algs4.DijkstraSP;
import es.upm.dit.adsw.movies.Movie;

public class GraphLoaderSmokeTest {

	public static void main(String[] args) throws Exception {
		String path = new String("data/");
			
		List<Movie> movies = Movie.allFromFile(path + "metadata.tsv", path + "cast.tsv");

		GraphLoader loader = new GraphLoader();
		loader.loadGraph(movies, (int) GraphLoader.actorsCount(path + "cast.tsv"));

		System.out.println("Actores no repetidos: " + loader.actorsCount);
		int numero = loader.actorsMap.get("Kevin Bacon");
		System.out.println("ID de Kevin Bacon: " + numero);
		System.out.println("Grado de Kevin Bacon: " + loader.g.outdegree(numero));
		System.out.println("----------");
		DijkstraSP d = new DijkstraSP(loader.g, numero);
		
		System.out.println("Distancia de Kevin Bacon a Carmen Machi: "+ d.distTo(loader.actorsMap.get("Carmen Machi")));


	}



}
