﻿package es.upm.dit.adsw.wc;

/**
 * Contenedor para asociar un contador a una palabra.
 *
 * @author jose a. manas
 * @version 8.3.2016
 */
public class Registro implements Comparable<Registro> {
	private final String clave;
	private int cnt;

	/**
	 * Constructor.
	 * El contador de inicia a 1.
	 *
	 * @param clave palabra.
	 */
	public Registro(String clave) {
		this.clave = clave;
		this.cnt = 1;
	}

	/**
	 * Getter.
	 *
	 * @return palabra.
	 */
	public String getClave() {
		return clave;
	}

	/**
	 * Getter.
	 *
	 * @return contador.
	 */
	public int getCnt() {
		return cnt;
	}

	/**
	 * Incrementa el contador.
	 */
	public void inc() {
		this.cnt++;
	}

	@Override
	/**
	 * Compares this object with the specified object for order.
	 * Returns a negative integer, zero, or a positive integer
	 * as this object is less than, equal to, or greater than the specified object.
	 *
	 * @param   o the object to be compared.
	 * @return a negative integer, zero, or a positive integer as this object
	 *          is less than, equal to, or greater than the specified object.
	 */
	public int compareTo(Registro o) {
		return cnt - o.cnt;
	}

	public String toString() {
		return String.format("[%s -> %d]", clave, cnt);
	}
}
