﻿package es.upm.dit.adsw.lista;

/**
 * Lista doblemente enlazada. La lista tiene una capacidad máxima, y si se llena
 * no se pueden añadir más valores.
 * 
 * @author alejandro alonso
 * @author juan a. de la puente
 * @version 2021.02.15
 */
public class ListaDoblementeEnlazada implements Lista {

	private int maxValores;  // capacidad de la lista
	private int nValores;    // número de valores almacenados
	private Celda primero;   // celda con el primer valor de la lista
	private Celda ultimo;    // celda con el último valor de la lista

	/**
	 * Constructor
	 * 
	 * @param maxValores Número máximo de elementos en la lista
	 */
	public ListaDoblementeEnlazada(int maxValores) {
		this.nValores   = 0;
		this.maxValores = maxValores;
		this.primero    = null;
		this.ultimo     = null;		
	}

	/**
	 * Obtener información sobre el estado de la lista
	 * @return True, si la lista está llena
	 */
	@Override
	public boolean estaLlena()  {
		return nValores == maxValores;
	}

	/**
	 * Obtener información sobre el estado de la lista
	 * @return True, si la lista está vacía
	 */
	@Override
	public boolean estaVacia()  {
		return nValores == 0;
	}

	/** 
	 * Obtener el número de elementos en la lista
	 * @return Número de elementos
	 */
	@Override
	public int getNValores() {
		return nValores;
	}

	/**
	 * Añadir un elemento en la lista
	 * 
	 * @param valor El valor que se debe almacenar
	 * @exception IllegalStateException si la lista está llena.
	 */
	@Override
	public void pon(int valor) throws IllegalStateException {

		if (estaLlena()) {
			throw new IllegalStateException("Lista llena");
		}

		if (estaVacia()) {
			Celda nuevaCelda = new Celda(null, null, valor);
			primero = nuevaCelda;
			ultimo  = nuevaCelda;			
		} else {
			Celda nuevaCelda = new Celda(null, ultimo, valor);
			ultimo           = nuevaCelda;
			ultimo.setAnterior(nuevaCelda);
		}
		nValores++;
	}

	/**
	 * Eliminar y obtener un elemento en la lista
	 * 
	 * @return Retorna el primer valor en la lista
	 * @exception IllegalStateException si la lista está vacia.
	 */
	@Override
	public int quita() throws IllegalStateException {

		if (estaVacia()) {
			throw new IllegalStateException("Lista vacia");
		}
		Celda auxCelda = primero;

		nValores--;

		if (estaVacia()) {
			int valor = primero.getValor();
			primero = null;
			ultimo  = null;
			return valor;
		} else {
			primero = auxCelda.getAnterior();
			primero.setSiguiente(null);
			return auxCelda.getValor();
		}
	}

	/**
	 * Comprobar si un valor está almacenado en la lista
	 * @param Valor  El valor a comprobar
	 * @return True, si el valor está en la lista
	 */
	@Override
	public boolean estaElValor(int Valor) {
		return false;
	}
	
	public String toString() {

		String lista = "Lista: [ ";

		if (estaVacia()) {
			lista = lista + "null";
		} else {
			Celda auxCelda = primero;
			while (auxCelda != null) {
				lista = lista + auxCelda.getValor() + " ";
				auxCelda = auxCelda.getAnterior();
			}
		}

		return lista + " ]";
	}

}
