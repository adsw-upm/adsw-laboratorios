﻿package es.upm.dit.adsw.wc;

import java.io.File;
import java.io.IOException;
import java.util.*;

/**
 * Analizador de textos.
 *
 * @author jose a. manas
 * @author juan a. de la puente
 * @version 2020.02.03
 */
public class WordCounter {

	/**
	 * Tabla de palabras y registro de veces que aparecen en el texto
	 */
	private Map<String, Registro> S1;

	/**
	 * Registros del número de veces que aparece cada palabra.
	 */
	private Registro[] S2;

	/**
	 * Constructor.
	 */
	public WordCounter() {
		S1 = new HashMap<>();
	}

	/**
	 * Volvemos a empezar.
	 * Vacía el diccionario y anula tabla de S2 ordenados.
	 */
	public void reset() {
		S1.clear();
		S2 = null;
	}

	/**
	 * Carga un fichero de texto.
	 * Anula la tabla de S2 ordenados.
	 *
	 * @param file fichero.
	 * @throws IOException si hay problemas con el fichero.
	 */
	public void load(File file)
			throws IOException {
		S2 = null;
		Scanner scanner = new Scanner(file, "UTF-8");
		scanner.useDelimiter("[^\\p{javaLowerCase}\\p{javaUpperCase}]+");
		while (scanner.hasNext()) {
			String word = scanner.next().toLowerCase();
			put(word);
		}
		scanner.close();
	}

	/**
	 * Carga un texto.
	 * Anula la tabla de S2 ordenados.
	 *
	 * @param s texto.
	 */
	public void load(String s) {
		S2 = null;
		Scanner scanner = new Scanner(s);
		scanner.useDelimiter("[^\\p{javaLowerCase}\\p{javaUpperCase}]+");
		while (scanner.hasNext()) {
			String word = scanner.next().toLowerCase();
			put(word);
		}
		scanner.close();
	}

	/**
	 * Mete una palabra en el diccionario.
	 * Si es nueva, el contador empieza en 1.
	 * Si ya estaba, el contador se incrementa en 1.
	 *
	 * @param word palabra.
	 */
	private void put(String word) {
		Registro registro = S1.get(word);
		if (registro == null)
			S1.put(word, new Registro(word));
		else
			registro.inc();
	}

	/**
	 * Tamaño del diccionario.
	 *
	 * @return numero de palabras.
	 */
	public int size() {
		return S1.size();
	}

	/**
	 * Devuelve las n palabras más usadas (si n es positivo).
	 * Devuelve las n palabras menos utilizadas (si n es negativo).
	 * La lista devuelta tiene un tamaño entre 0 y n;
	 * es menor que n si no hay suficientes palabras diferentes.
	 *
	 * @param n numero de palabras contando desde el principio o desde el final.
	 * @return lista de hasta n registros.
	 */
	public List<Registro> getTop(int n) {
		getDatos();
		if (n < 0)
			return getMyBottom(Math.min(-n, S2.length));
		else
			return getMyTop(Math.min(n, S2.length));
	}

	private List<Registro> getMyBottom(int m) {
		List<Registro> list = new ArrayList<>();
		for (int i = 0; i < m; i++)
			list.add(S2[i]);
		return list;
	}

	private List<Registro> getMyTop(int m) {
		List<Registro> list = new ArrayList<>();
		for (int i = 0; i < m; i++) {
			int pos = S2.length - 1 - i;
			list.add(S2[pos]);
		}
		return list;
	}

	private void getDatos() {
		if (S2 == null) {
			Collection<Registro> values = S1.values();
			S2 = new Registro[values.size()];
			int at = 0;
			for (Registro registro : values)
				S2[at++] = registro;
			Arrays.sort(S2);
		}
	}

	/**
	 * Devuelve cuántas palabras hay por debajo de un umbral c.
	 * El resultado es un numero entre 0 y N, siendo N el número de palabras diferentes en el fichero.
	 *
	 * @param c umbral de cuenta.
	 * @return numero de palabras que aparcecen en el texto menos de c veces.
	 */
	public int countBelow(int c) {
		getDatos();

		for (int i = 0; i < S2.length; i++) {
			if (S2[i].getCnt() >= c)
				return i;
		}
		return S2.length;
	}

	// smoke test
	public static void main(String[] args) {
		String text = "¿Qué es mi barco? Mi tesoro. \n" +
				"¿Qué es mi Dios? La libertad. \n" +
				"¿Mi ley? ¡La fuerza y el viento! \n" +
				"¿Mi única patria? ¡La mar!";

		WordCounter wc = new WordCounter();
		wc.load(text);
		System.out.println("size(): " + wc.size());
		dump("top(5):  ", wc.getTop(5));
		dump("top(-5): ", wc.getTop(-5));
		System.out.println("countbelow(2): " + wc.countBelow(2));
	}

	private static void dump(String label, List<Registro> list) {
		System.out.println(label);
		for (Registro r : list)
			System.out.printf("  %d: %s%n", r.getCnt(), r.getClave());
		System.out.println();
	}

	public void print() {
		for (String key : S1.keySet())
			System.out.printf("%s -> %s%n", key, S1.get(key));
		getDatos();
		for (Registro reg : S2)
			System.out.println(reg);
	}
}
