﻿package es.upm.dit.adsw.lista;

/**
 * Interfaz de una lista FIFO
 *   
 * @author Alejandro Alonso
 * @version  2023.02.11
 */

public interface Lista {

	/**
	 * Obtener información sobre el estado de la lista
	 * @return True, si la lista está llena
	 */
	boolean estaLlena();

	/**
	 * Obtener información sobre el estado de la lista
	 * @return True, si la lista está vacía
	 */
	boolean estaVacia();

	/** 
	 * Obtener el número de elementos en la lista
	 * @return Número de elementos
	 */
	int getNValores();

	/**
	 * Añadir un elemento en la lista
	 * 
	 * @param valor El valor que se debe almacenar
	 * @exception IllegalStateException si la lista está llena.
	 */
	void pon(int valor) throws IllegalStateException;

	/**
	 * Eliminar y obtener un elemento en la lista
	 * 
	 * @return Retorna el primer valor en la lista
	 * @exception IllegalStateException si la lista está vacia.
	 */
	int quita() throws IllegalStateException;

	/**
	 * Comprobar si un valor está almacenado en la lista
	 * @param Valor  El valor a comprobar
	 * @return True, si el valor está en la lista
	 */
	boolean estaElValor(int Valor);

}