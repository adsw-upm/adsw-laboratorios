﻿package es.upm.dit.adsw.lista;

/**
 * La celda que mantiene un enlace a una celda anterior, un enlace a la celda 
 * siguiente y el valor de la celda
 * 
 * @author Alejandro Alonso
 * @version 2023.02.11
 */
public class Celda {

	private Celda anterior;
	private Celda siguiente;
	private int valor;
	
	/**
	 * Constructor de la celda
	 */
	public Celda () {
		this.anterior  = null;
		this.siguiente = null;
		this.valor     = 0;
	}

	/**
	 * Constructor de la celda
	 * 
	 * @param anterior La celda anterior
	 * @param siguiente La celda posterior
	 * @param valor El contenido a mantener
	 */
	public Celda (Celda anterior, Celda siguiente, int valor) {
		this.anterior  = anterior;
		this.siguiente = siguiente;
		this.valor     = valor;
	}
	
	/**
	 * Obtener la celda anterior
	 * @return	La celda anterior
	 */
	public Celda getAnterior() {
		return anterior;
	}

	/**
	 * Asignar la celda al campo anterior
	 * @param  anterior El enlace a la celda que se debe guardar
	 */
	public void setAnterior(Celda anterior) {
		this.anterior = anterior;
	}

	/**
	 * Obtener la celda siguiente
	 * @return	La celda siguiente
	 */
	public Celda getSiguiente() {
		return siguiente;
	}

	
	/**
	 * Asignar la celda al campo siguiente
	 * @param siguiente El contenido a guardar
	 */
	public void setSiguiente(Celda siguiente) {
		this.siguiente = siguiente;
	}

	/** 
	 * Obtener el valor de la celda
	 * @return	El valor de la celda
	 */
	public int getValor() {
		return valor;
	}

	/** El valor que se debe almacenar en la celda
	 * @param valor  A almacenar
	 */
	public void setValor(int valor) {
		this.valor = valor;
	}

	@Override
	public String toString() {
		return "Celda [anterior=" + anterior + ", siguiente=" + siguiente + ", valor=" + valor + "]";
	}

}
