﻿package es.upm.dit.adsw.wc;

import java.io.File;
import java.io.IOException;

/**
 * Medidor de tiempo de ejecución
 * Textos de ejemplo de dominio público, descargados de http://www.gutenberg.org/.
 * 
 * @author jose a. manas
 * @author juan a. de la puente
 * @version 2021.02.17
 */
@SuppressWarnings("unused")
public class Meter {
	private static final String DIR = "libros";
	private static final String LAZARILLO = "Lazarillo.txt";
	private static final String QUIJOTE = "DonQuijote.txt";
	private static final String SHAKESPEARE = "Shakespeare.txt";

	public static void main(String[] args) throws IOException {
		//measure(LAZARILLO);
		measure(QUIJOTE);
		//measure(SHAKESPEARE);
		//measure(QUIJOTE, LAZARILLO);
		//measure(QUIJOTE, LAZARILLO, SHAKESPEARE);
	}

	/**
	 * Hace un recuento de palabras contenidas en un conjunto de libros
	 * @param books nombres de los archivos de los libros
	 * @throws IOException si hay algún problema al leer los archivos
	 */
	private static void measure(String... books) throws IOException {
		WordCounter wc = new WordCounter();
		long t0 = System.currentTimeMillis();
		for (String book : books) {
			File file = new File(DIR, book);
			wc.load(file);
		}
		long t2 = System.currentTimeMillis();

		System.out.printf("tamaño: %d palabras; tiempo: %d ms%n", wc.size(), t2 - t0);

	}
}
