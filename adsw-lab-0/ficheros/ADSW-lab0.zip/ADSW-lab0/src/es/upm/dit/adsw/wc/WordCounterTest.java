﻿package es.upm.dit.adsw.wc;

import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class WordCounterTest {
	private WordCounter wc;

	@Before
	public void setUp() {
		wc = new WordCounter();
	}

	@Test
	public void test00() {
		WordCounter wc = new WordCounter();
		assertEquals(0, wc.getTop(10).size());
		assertEquals(0, wc.getTop(-10).size());
		assertEquals(0, wc.countBelow(1));
		assertEquals(0, wc.countBelow(2));
		assertEquals(0, wc.size());
	}

	@Test
	public void test01() {
		wc.reset();
		wc.load("uno");
		check(wc.getTop(10), new R("uno", 1));
		check(wc.getTop(-10), new R("uno", 1));
		assertEquals(1, wc.getTop(10).size());
		assertEquals(0, wc.countBelow(1));
		assertEquals(1, wc.countBelow(2));
		assertEquals(1, wc.countBelow(3));
		assertEquals(1, wc.size());

		wc.reset();
		wc.countBelow(1);
		assertEquals(0, wc.getTop(10).size());
		assertEquals(0, wc.getTop(-10).size());
		assertEquals(0, wc.countBelow(1));
		assertEquals(0, wc.countBelow(2));
		assertEquals(0, wc.size());
	}

	@Test
	public void test012() {
		wc.reset();
		wc.load("uno dos dos");
		check(wc.getTop(10), new R("dos", 2), new R("uno", 1));
		check(wc.getTop(-10), new R("uno", 1), new R("dos", 2));
		assertEquals(2, wc.size());
		assertEquals(0, wc.countBelow(1));
		assertEquals(1, wc.countBelow(2));
		assertEquals(2, wc.countBelow(3));
	}

	@Test
	public void test0123() {
		wc.reset();
		wc.load("uno dos dos tres tres tres");
		check(wc.getTop(10), new R("tres", 3), new R("dos", 2), new R("uno", 1));
		check(wc.getTop(-10), new R("uno", 1), new R("dos", 2), new R("tres", 3));
		assertEquals(0, wc.countBelow(1));
		assertEquals(1, wc.countBelow(2));
		assertEquals(2, wc.countBelow(3));
		assertEquals(3, wc.countBelow(4));
		assertEquals(3, wc.size());
	}

	@Test
	public void test023() {
		wc.reset();
		wc.load("dos dos tres tres tres");
		check(wc.getTop(10), new R("tres", 3), new R("dos", 2));
		check(wc.getTop(-10), new R("dos", 2), new R("tres", 3));
		assertEquals(0, wc.countBelow(1));
		assertEquals(0, wc.countBelow(2));
		assertEquals(1, wc.countBelow(3));
		assertEquals(2, wc.countBelow(4));
		assertEquals(2, wc.size());
	}

	@Test
	public void test21() {
		wc.reset();
		wc.load("dos dos");
		wc.load("tres tres tres");
		wc.load("dos dos tres tres tres");
		check(wc.getTop(10), new R("tres", 6), new R("dos", 4));
		check(wc.getTop(-10), new R("dos", 4), new R("tres", 6));
		assertEquals(0, wc.countBelow(1));
		assertEquals(0, wc.countBelow(2));
		assertEquals(0, wc.countBelow(3));
		assertEquals(0, wc.countBelow(4));
		assertEquals(1, wc.countBelow(5));
		assertEquals(2, wc.size());
	}

	@Test
	public void test22() {
		wc.reset();
		wc.load("dos dos");
		wc.reset();
		wc.load("tres tres tres");
		check(wc.getTop(10), new R("tres", 3));
		check(wc.getTop(-10), new R("tres", 3));
		assertEquals(0, wc.countBelow(1));
		assertEquals(0, wc.countBelow(2));
		assertEquals(0, wc.countBelow(3));
		assertEquals(1, wc.countBelow(4));
		assertEquals(1, wc.size());
	}

	@Test
	public void test_() {
		wc.reset();
		wc.load("word");
		List<Registro> list = wc.getTop(1);
		assertEquals(1, list.size());
		Registro r0 = list.get(0);
		assertEquals("word", r0.getClave());
		assertEquals(1, r0.getCnt());
	}

	/**
	 * Comprueba si una lista contiene un conjunto de palabras y su número de repeticiones
	 * @param list lista que se evalúa
	 * @param expected palabras y repeticiones
	 */
	private void check(List<Registro> list, R... expected) {
		R[] observed = new R[list.size()];
		R[] reversed = new R[list.size()];
		int countUp = 0;
		int countDown = list.size() - 1;
		for (Registro registro : list) {
			R r = new R(registro);
			observed[countUp++] = r;
			reversed[countDown--] = r;
		}

		boolean ok = true;
		ok &= expected.length == list.size();
		ok &= Arrays.deepEquals(expected, observed) || Arrays.deepEquals(expected, reversed);

		if (!ok) {
			System.out.println("esperado:  " + Arrays.toString(expected));
			System.out.println("observado: " + Arrays.toString(observed));
		}
		assertTrue(ok);
	}

	/**
	 * Clase auxiliar que representa una palabra y un número de repeticiones
	 */
	private class R {
		final String key;
		final int cnt;

		R(String key, int cnt) {
			this.key = key;
			this.cnt = cnt;
		}

		R(Registro registro) {
			this.key = registro.getClave();
			this.cnt = registro.getCnt();
		}

		@Override
		public String toString() {
			return String.format("[%s, %d]", key, cnt);
		}

		@Override
		public boolean equals(Object o) {
			if (this == o) return true;
			if (o == null || getClass() != o.getClass()) return false;

			R r = (R) o;

			if (cnt != r.cnt) return false;
			return key.equals(r.key);
		}

		@Override
		public int hashCode() {
			int result = key.hashCode();
			result = 31 * result + cnt;
			return result;
		}
	}
}
