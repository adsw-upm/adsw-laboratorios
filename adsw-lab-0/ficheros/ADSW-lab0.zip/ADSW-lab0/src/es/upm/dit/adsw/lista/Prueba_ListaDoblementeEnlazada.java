﻿package es.upm.dit.adsw.lista;

// smoke test
public class Prueba_ListaDoblementeEnlazada {
	
	public static void main(String[] args) {
		
		int nMaxValores       = 3;	
		int valor             = 0;
		boolean imprimirLista = true;
		ListaDoblementeEnlazada lista = new ListaDoblementeEnlazada(nMaxValores);

		try {
			lista.pon(1);
			if (imprimirLista) System.out.println(lista.toString());
		} catch (Exception e) {
			System.out.println("Error: " + e.getMessage());
		}

		
		try {
			lista.pon(2);
			if (imprimirLista) System.out.println(lista.toString());
		} catch (Exception e) {
			System.out.println("Error: " + e.getMessage());
		}
		
		try {
			lista.pon(3);
			if (imprimirLista) System.out.println(lista.toString());
		} catch (Exception e) {
			System.out.println("Error: " + e.getMessage());
		}
		
		try {
			lista.pon(4);
			if (imprimirLista) System.out.println(lista.toString());
		} catch (Exception e) {
			System.out.println("Error: " + e.getMessage());
		}

		try {
			System.out.print(valor);
			if (imprimirLista) System.out.print(" " + lista.toString());			
			System.out.println();		
		} catch (Exception e) {
			System.out.println("Error: " + e.getMessage());
		}

		try {
			valor = lista.quita();
			System.out.print(valor);
			if (imprimirLista) System.out.print(" " + lista.toString());			
			System.out.println();		
		} catch (Exception e) {
			System.out.println("Error: " + e.getMessage());
		}

		try {
			valor = lista.quita();
			System.out.print(valor);
			if (imprimirLista) System.out.print(" " + lista.toString());			
			System.out.println();		
		} catch (Exception e) {
			System.out.println("Error: " + e.getMessage());
		}
		
	}
}
