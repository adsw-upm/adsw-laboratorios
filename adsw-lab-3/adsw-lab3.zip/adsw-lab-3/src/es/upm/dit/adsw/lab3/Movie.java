package es.upm.dit.adsw.lab3;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;


/**
 * Clase que representa una película en el conjunto de datos (dataset) de la asignatura.
 * 
 * Los atributos son metadatos de la película tales como la fecha de lanzamiento o el idioma original.
 *
 */
public class Movie implements Comparable<Movie>, Serializable {

	private static final long serialVersionUID = 1L;
	
	/**
	 * Identificador único de la película dentro del dataset.
	 */
	public int id;
	/**
	 * Popularidad de la película. Puede ser un float elevado (del orden de cientos)
	 */
	float popularity;
	/**
	 * Puntuación media obtenida. Es un valor entre 0 y 10
	 */
	float vote_average;

	/**
	 * Identificador en la plataforma IMDB
	 */
	String imdb_id;
	/**
	 * Título original de la película
	 */
	public String original_title;
	/**
	 * Presupuesto de la película, en dólares
	 */
	Integer budget;
	/**
	 * Géneros de la película. Ejemplos: "Drama", "Comedy"
	 */
	List<String> genres;
	/**
	 * Página web con información de la película
	 */
	String homepage;
	/**
	 * Código del idioma original. Ejemplos: "en", "es", "fr", "de"... 
	 */
	String original_language;
	/**
	 * Sinopsis de la película, en inglés
	 */
	String overview;
	/**
	 * Fecha de lanzamiento
	 */
	LocalDate release_date;
	/**
	 * Recaudación
	 */
	Float revenue;
	/**
	 * Longitud del metraje, en minutos
	 */
	Float runtime;
	/**
	 * Código de los idiomas hablados en la película. Ejemplos: "en", "es", "de"...
	 */
	List<String> spoken_languages;
	/**
	 * Eslógan de la película. Ejemplo para la película "Die Hard" (La jungla de cristal): "40 Stories. Twelve Terrorists. One Cop. Die Hard."
	 */
	String tagline;
	/**
	 * Título de la película en inglés
	 */
	String title;
	/**
	 * Película para adultos o para el público general
	 */
	boolean adult;
	/**
	 * Elenco de la película. Ejemplo: "Tom Hanks", "Matt Damon"...
	 */
	List<String> cast;
	/**
	 * Constructor principal de películas
	 * @param id Identificador único de la película dentro del dataset
	 * @param popularity Popularidad de la película. Puede ser un float elevado (del orden de cientos)
	 * @param vote_average Puntuación media obtenida. Es un valor entre 0 y 10
	 * @param imdb_id Identificador en la plataforma IMDB
	 * @param original_title Título en el idioma original de la película
	 * @param budget Presupuesto
	 * @param genres Lista de géneros a los que pertenece la película. Ejemplos: "Drama", "Comedy"...
	 * @param homepage Página web con información de la película
	 * @param original_language Código del idioma original de la película. Ejemplos: "en", "es", "fr", "de"...
	 * @param overview Sinopsis
	 * @param release_date Fecha de lanzamiento
	 * @param revenue Recaudación
	 * @param runtime Longitud del metraje, en minutos
	 * @param spoken_languages Código de los idiomas hablados en la película. Ejemplos: "en", "es", "de"...
	 * @param tagline Eslógan de la película. Ejemplo para la película "Die Hard" (La jungla de cristal): "40 Stories. Twelve Terrorists. One Cop. Die Hard."
	 * @param title Título de la película en inglés
	 * @param adult Película para adultos o para el público general
	 */
	public Movie(int id,
			float popularity,
			float vote_average,
			String imdb_id,
			String original_title,
			Integer budget,
			String genres,
			String homepage,
			String original_language,
			String overview,
			LocalDate release_date,
			Float revenue,
			Float runtime,
			String spoken_languages,
			String tagline,
			String title,
			boolean adult) {
		this.id = id;
		this.popularity = popularity;
		this.vote_average = vote_average;
		this.imdb_id = imdb_id;
		this.original_title = original_title;
		this.budget = budget;
		this.genres = Arrays.asList(genres.split(","));
		this.homepage = homepage;
		this.original_language = original_language;
		this.overview = overview;
		this.release_date = release_date;
		this.revenue = revenue;
		this.runtime = runtime;
		this.spoken_languages = Arrays.asList(spoken_languages.split(","));
		this.tagline = tagline;
		this.title = title;
		this.adult = adult;
		this.cast = new ArrayList<String>();

	}
	/**
	 * Construye una lista de películas a partir del fichero de metadatos y el fichero con el elenco.
	 * @param metadata Fichero TSV con metadatos
	 * @param castfile Fichero TSV con el elenco 
	 * @return Lista de películas encontradas
	 * @throws FileNotFoundException Se genera una excepción si no se detecta el fichero
	 */
	public static List<Movie> allFromFile(String metadata, String castfile) throws FileNotFoundException {
		List<Movie> pelis = allFromFile(metadata);
		File cf = new File(castfile);
		try (Scanner reader = new Scanner(cf)) {
			while (reader.hasNextLine()) {
				List<String> cast = new ArrayList<String>(Arrays.asList(reader.nextLine().split("\t")));
				int movieid = Integer.parseInt(cast.remove(0));
				for(Movie peli: pelis) {
					if(peli.id == movieid) {
						peli.setCast(cast);
						break;
					}
				}

			}
		}
		return pelis;
	}    
	/**
	 * Construye una lista de películas a partir del fichero de metadatos. Las películas tendrán un elenco (cast) vacío.
	 * @param metadata Fichero TSV con metadatos
	 * @return Lista de películas encontradas
	 * @throws FileNotFoundException Se genera una excepción si no se detecta el fichero
	 */
	public static ArrayList<Movie> allFromFile(String metadata) throws FileNotFoundException {
		int wrong = 0;
		int right = 0;
		ArrayList<Movie> pelis = new ArrayList<Movie>();
		File meta = new File(metadata);
		Scanner reader = new Scanner(meta);
		List<String> header = Arrays.asList(reader.nextLine().split("\t"));
		Map<String, Integer> fields = new HashMap<String, Integer>();

		for(int i=0; i<header.size(); i++) {
			fields.put(header.get(i), i);
		}

		while (reader.hasNextLine()) {
			String[] data = reader.nextLine().split("\t");
			if(data.length < 1) {
				continue;
			}
			try { 
				Movie peli = new Movie(
						Integer.parseInt(data[fields.get("id")]),
						Float.parseFloat(data[fields.get("popularity")]),
						Float.parseFloat(data[fields.get("vote_average")]),
						data[fields.get("imdb_id")],
						data[fields.get("original_title")],
						Integer.parseInt(data[fields.get("budget")]),
						data[fields.get("genres")],
						data[fields.get("homepage")],
						data[fields.get("original_language")],
						data[fields.get("overview")],
						LocalDate.parse(data[fields.get("release_date")]),
						Float.parseFloat(data[fields.get("revenue")]),
						Float.parseFloat(data[fields.get("runtime")]),
						data[fields.get("spoken_languages")],
						data[fields.get("tagline")],
						data[fields.get("title")],
						data[fields.get("adult")] == "True");
				pelis.add(peli);
			} catch(ArrayIndexOutOfBoundsException e) {
				System.out.println("Unknown field: " + e.getMessage());
				wrong++;
				continue;      
			} catch(NumberFormatException e) {
				System.out.println(String.join(" ", data));
				System.out.println("Badly formatted number: " + e.getMessage());
				wrong++;
				continue;
			} catch( java.time.format.DateTimeParseException e) {
				System.out.println("Bad date: " + e.getMessage());
				wrong++;
				continue;	
			}
			right++;
		}
		reader.close();
		System.out.println("Imported: " + right + "/" + (right + wrong));
		return pelis;
	}

	public static Map<Integer, List<String>> allCastFromFile(String castfile, List<Movie> movies) throws FileNotFoundException {
		Map<Integer, List<String>> cast =new TreeMap<Integer, List<String>>();
		File cf = new File(castfile);
		try (Scanner reader = new Scanner(cf)) {
			while (reader.hasNextLine()) {
				ArrayList<String> actors = new ArrayList<String>(Arrays.asList(reader.nextLine().split("\t")));
				int movieid = Integer.parseInt(actors.remove(0));
				for(Movie peli: movies) {
					if(peli.id == movieid) {
						cast.put(movieid, actors);
						break;
					}
				}

			}
		}
		return cast;
	}

	/**
	 * Actualiza la lista de actores de la película (elenco)
	 * @param cast Listado con el nombre de los/as actores/actrices
	 */
	public void setCast(List<String> cast){
		this.cast = cast;
	}    

	/**
	 * Añade un nombre a la lista de actores
	 * @param name nombre del actor a añadir
	 */
	public void addActor(String name){
		this.cast.add(name);
	}    
	
	
	/**
	 * Obtener la lista del elenco
	 * @return El elenco
	 */
	public List<String>  getCast() {
		return this.cast;
	}
	
	/**
	 * Muestra la película como una cadena de texto. 
	 * Por el momento, sólo muestra título original, en inglés y popularidad.
	 */
	public String toString(){
		return this.title + " (" + this.original_title + ") [" + this.popularity + "]";
	}

	/**
	 * Compara la película con otra. La implementación pedida debería comparar en función de la popularidad de las películas.
	 */
	@Override
	public int compareTo(Movie other) {
		return Integer.valueOf(this.id).compareTo(Integer.valueOf(other.id));
	}
}
