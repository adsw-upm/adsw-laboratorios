package es.upm.dit.adsw.lab3;
import es.upm.dit.adsw.monitor.MonitorSegmentos;

public class Pool {

	Hebra[] hebras; 
	int nHebras;
	MonitorSegmentos monitor;
	
	//constructor: nTareas, gestorTrozos
	// Algoritmo para procesar
	public Pool (int nHebras, MonitorSegmentos monitor) {
		this.nHebras = nHebras;
		this.hebras  = new Hebra[nHebras];
		this.monitor     = monitor;
	}
	
	public void activate() {
		for (int i = 0; i < nHebras; i++) {
			hebras[i] = new Hebra(monitor, i);
			hebras[i].start();
		}
		// Informar cuando termine, si merece la pena
		//System.out.println("Número de hebras: " + nHebras + " " + hebras[0].activeCount());
		//System.out.println("Número de hebras: " + nHebras + " " + Thread.activeCount());

	}
	
}
