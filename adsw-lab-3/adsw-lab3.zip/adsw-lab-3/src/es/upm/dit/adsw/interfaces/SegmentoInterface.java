package es.upm.dit.adsw.interfaces;

import java.util.List;
import java.util.Map;
import es.upm.dit.adsw.lab3.Movie;

/**
 * @author aalonso
 * Este interface modela un segmento. Gestiona una list de películas y
 * una estructura de datos que asocia un actor con los identificadores de las 
 * películas en las que ha actuado
 */
public interface SegmentoInterface {

	
	public Map<Integer, List<String>> getCast();
	
	public List<Movie> getMovies();
		
}

