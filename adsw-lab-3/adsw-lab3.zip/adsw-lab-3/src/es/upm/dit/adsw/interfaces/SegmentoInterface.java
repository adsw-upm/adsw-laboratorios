package es.upm.dit.adsw.interfaces;

import java.util.List;
import java.util.Map;
import es.upm.dit.adsw.lab3.Movie;

/**
 * @author aalonso
 * Este interface modela un segmento. Gestiona una lista de películas y
 * una estructura de datos que asocia un identificador de una película con una
 * lista de los actores que han actuado.
 */

public interface SegmentoInterface {

	
	public Map<Integer, List<String>> getCast();
	
	public List<Movie> getMovies();
		
}

