package es.upm.dit.adsw.lab3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.ConsoleHandler;
import java.util.logging.Logger;
import java.util.logging.Level;
import es.upm.dit.adsw.monitor.MonitorSegmentos;
import es.upm.dit.adsw.interfaces.SegmentoInterface;

/**
 * @author aalonso
 *
 */
public class InvertirActores {

	// Lista de las películas
	private List<Movie> movies; 

	// Relación de la id de película con los actores que actuaron
	private Map<Integer, List<String>> cast;

	// Lista para almacenar los resultados
	private List<Map<String, List<Movie>>> resultados 
	= new  ArrayList<Map<String, List<Movie>>>();

	// Lista con la inversión de los actores
	private Map<String, List<Movie>> inversionActores = new HashMap<String, List<Movie>>();

	private List<SegmentoInterface> segmentos = new ArrayList<SegmentoInterface>();
	
	private  MonitorSegmentos monitor;

	private int nSegmentos;

	static {
		System.setProperty("java.util.logging.SimpleFormatter.format",
				"[%1$tF %1$tT][%4$-7s] [%5$s] [%2$-7s] %n");
	}

	static final Logger LOGGER = Logger.getLogger(InvertirActores.class.getName());

	/**
	 * Recibe los ficheros de las películas, su elemco (cast) y número de segmentos. Accede
	 * a los ficheros y los guarda en estructuras de datos. 
	 * @param pathMovies Camino de las películas
	 * @param pathCast   Camino del elenco
	 * @param nSegmentos Número de segmentos
	 * @param monitor    Monitor para la comunicación con hebras
	 */
	public InvertirActores(String pathMovies, String pathCast, int nSegmentos, MonitorSegmentos monitor) {
		configurarLogger();
		// En el constructor se leen de los datos y generan los segmentos
		this.nSegmentos = nSegmentos;
		try {
			// Obtener movies
			this.movies = Movie.allFromFile(pathMovies);
			// Obtener cast
			this.cast   = Movie.allCastFromFile(pathCast, movies);
			// Generar segmentos
		} catch (Exception E) {
			System.out.println(E.toString());
		}
	}

	/**
	 * Recibe los ficheros de las películas, su elemco (cast) y número de segmentos. Accede
	 * a los ficheros y los guarda en estructuras de datos. 
	 * @param pathObject Camino de un fichero que agrupa películas y elencos
	 * @param nSegmentos Número de segmentos
	 * @param monitor    Monitor para la comunicación con hebras
	 */

	public InvertirActores(String pathObject, int nSegmentos,  MonitorSegmentos monitor) {

		configurarLogger();

		this.nSegmentos = nSegmentos;
		this.monitor    = monitor;
		try {
			FileInputStream fi = new FileInputStream(new File(pathObject));
			ObjectInputStream oi = new ObjectInputStream(fi);

			// Read objects
			Segmento segmento = (Segmento) oi.readObject();

			cast   = segmento.getCast();
			movies = segmento.getMovies();

			oi.close();
			fi.close();
			InvertirActores.LOGGER.info("Se ha leido el fichero, con " + movies.size() + "/" +cast.size() + "registros");
		} catch (FileNotFoundException e) {
			System.out.println("File not found");
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Error initializing stream");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	/**
	 * Configuracion de un logger
	 */
	private void configurarLogger() {
		//Configurar un handler
		ConsoleHandler handler;
		handler = new ConsoleHandler();
		handler.setLevel(Level.INFO);
		LOGGER.addHandler(handler);
		LOGGER.setLevel(Level.INFO);
	}


	/**
	 * Integrar los resultados obtenidos de los fragmentos generados
	 */
	private void integrarResultados() {
		for (Map<String, List<Movie>> resultado : resultados) {
			try {
				for (String actor : resultado.keySet()) {
					if (inversionActores.containsKey(actor)) {
						List<Movie> lista = resultado.get(actor);
						for (Movie movie : lista) {
							inversionActores.get(actor).add(movie);
						}
					} else {
						inversionActores.put(actor, resultado.get(actor));
					}
				} 
			} catch (Exception E) {
				InvertirActores.LOGGER.severe("Unexpected exception");				
			}
		}
		InvertirActores.LOGGER.info("Se han integrado " + inversionActores.size() +  " resultados");
	}

	/**
	 * Los segmentos generados se envían al monitor, para enviarlos a las hebras. A continuación,
	 * hay que recibr los segmentos que han procesado
	 */
	private void procesarSegmentos() {
		
		// TODO alumnos
		// Para segmento, enviarlo al monitor
		// Entrar en un bucle recibiendo resultados. 
		// Deben obtener tantos resultados como el número de segmentos
		// Finalizar el monitor. 
		
		
		InvertirActores.LOGGER.info("Se han recibido " + nResultados +  " resultados");
		integrarResultados();
		
	}

	/**
	 * Acceder a la lista de peliculas de un actor. Se retorna null
	 * si no es válido
	 * @param actor El actor
	 * @return La lista de películas
	 */
	public List<Movie> getActor(String actor) {
		return inversionActores.get(actor);
	}

	/**
	 * Mostrar las películas de un actor un actor
	 * @param actor El actor
	 */
	public void printActor(String actor) {
		List<Movie> moviesActor = inversionActores.get(actor);
		System.out.println(actor + " " + movies.size() + " peliculas");

		if (moviesActor != null && moviesActor.size() > 0) {
			for (Movie movie: moviesActor) {
				System.out.println(movie.original_title);
			}
		}
	}

	
	
	/**
	 * Generar los segmentos usando la clase Segmento
	 */
	public void generarSegmentos() {
		segmentos = Segmento.generarSegmentos(nSegmentos, movies, cast);
	}
	
	public static void main(String[] args) {

		String pathObject = "data_top100.txt";

		MonitorSegmentos monitor = new MonitorSegmentos();
		
		int nSegmentos = 10;
		InvertirActores inv = new InvertirActores(pathObject, nSegmentos, monitor);

		int nHebras = 5;
		Pool pool = new Pool(nHebras, monitor);
		pool.activate();

		inv.generarSegmentos();

		inv.procesarSegmentos();

		inv.printActor("Tom Hanks");
	}
}

