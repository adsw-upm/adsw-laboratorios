package es.upm.dit.adsw.geosocial;

import java.util.Objects;

/**
 * Clase principal que representa una localización en el mundo real.
 * 
 * Una localización se caracteriza poner unas coordenadas en el mapa (latitud y longitud) y un identificador del lugar en que está la localización.
 *
 */
public class Localizacion {
	private float latitud;
	private float longitud;
	
	public Localizacion(float latitud, float longitud) {
		super();
		this.latitud = latitud;
		this.longitud = longitud;
	}

	public float getLatitud() {
		return latitud;
	}

	public float getLongitud() {
		return longitud;
	}
	
	public boolean equals(Localizacion loc) {
		return this.latitud == loc.latitud && this.longitud == loc.longitud;
	}

	@Override
	public int hashCode() {
		return Objects.hash(latitud, longitud);
	}

	// aalonso: añadido para contains
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Localizacion other = (Localizacion) obj;
		return Float.floatToIntBits(latitud) == Float.floatToIntBits(other.latitud)
				&& Float.floatToIntBits(longitud) == Float.floatToIntBits(other.longitud);
	}

	@Override
	public String toString() {
		return "Localizacion [latitud=" + latitud + ", longitud=" + longitud + "]";
	}
	
}
