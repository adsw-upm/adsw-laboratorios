package es.upm.dit.adsw.geosocial.lab4;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import es.upm.dit.adsw.geosocial.Localizacion;
import es.upm.dit.adsw.geosocial.Registro;
import es.upm.dit.adsw.geosocial.interfaces.MonitorSegmentosInterface;
import es.upm.dit.adsw.geosocial.interfaces.ResultadoInterface;
import es.upm.dit.adsw.geosocial.interfaces.SegmentoInterface;

import java.util.HashMap;

/**
 * @author aalonso
 * Esta clase define una hebra que debe procesar segmentos. El resultado
 * es una estructura de datos que asocia una localización a los usuarios 
 * donde han estado.
 */
public class Hebra extends Thread{

	private MonitorSegmentosInterface monitor;
	private int id;

	public Hebra (MonitorSegmentosInterface monitor, int id) {
		this.monitor = monitor;
		this.id      = id;
	}

	
	/**
	 * Este método es el programa que ejecuta cada hebra
	 * 
	 * Ejecuta en un bucle para procesar los segmentos. Hay que solicitar un segmento,
	 * procesarlo y enviar el resultado. La comunicación es mediante un objeto de 
	 * MonitorSegmentos.
	 * 
	 * Al recibir un segmento hay que comprobar si ha finalizado el procesamiento
	 * de segmentos. 
	 * 
	 * Hay que comprobar si un segmento es null, para no procesarlo. 
	 *
	 */
	public void run() {
		AlmacenLab4.LOGGER.info("Inicia la hebra " + this.id);
		SegmentoInterface segmento;
		ResultadoInterface resultado;

		//mientras que hay huecos
		while (!monitor.estaFinalizado()) {
			try {
				segmento = monitor.getSegmento(this.id);
				if (segmento != null) {
					AlmacenLab4.LOGGER.fine("Recibido un segmento " + this.id);
					// Procesar segmento
					resultado = procesarSegmento(segmento);
					monitor.putResultado(resultado, this.id);		
					AlmacenLab4.LOGGER.fine("Enviado un resultado " + this.id);
				}
				AlmacenLab4.LOGGER.finer("Hebra terminado " + this.id);
			} catch (InterruptedException E) {
				AlmacenLab4.LOGGER.severe("Unexpected interrupted exception");
			} catch (Exception E) {
				AlmacenLab4.LOGGER.severe("Unexpected exception");				
			}
		} 
	}

	/**
	 * Este método procesa cada segmento. 
	 * @param segmento El segmento a prcesar
	 * @return El resutado al procesar el segmento
	 */
	public  ResultadoInterface procesarSegmento(SegmentoInterface segmento) {

		Map<Localizacion, List<Integer>> resultado = new HashMap<Localizacion, List<Integer>>();
		List <Registro> registros = segmento.getRegistros();
		for (Registro registro : registros) {
			if (resultado.containsKey(registro.getLoc())) {
				List<Integer> aux = resultado.get(registro.getLoc()); 
				if (!aux.contains(registro.getIdUsuario())) {
					aux.add(registro.getIdUsuario());
				}				
			} else {
				List<Integer> aux = new ArrayList<Integer>();
				aux.add(registro.getIdUsuario());
				resultado.put(registro.getLoc(), aux);
			}
		}

		return new Resultado(resultado);
	}
}

