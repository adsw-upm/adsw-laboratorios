package es.upm.dit.adsw.geosocial.lab4;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import es.upm.dit.adsw.geosocial.Registro;
import es.upm.dit.adsw.geosocial.interfaces.SegmentoInterface;

/**
 * @author aalonso
 * Este clase modela un segmento. Implementa el interfaz SegmentoInterface
 * El segmento se representa como una lista de registros..
 */

public class Segmento implements SegmentoInterface, Serializable{

	private static final long serialVersionUID = 1L;

	private List<Registro> registros;

	public Segmento (List<Registro> registros) {
		this.registros   = registros;
	}

	/**
	 * Genera los segmentos de los registros, según el número de segmentos 
	 * @param nSegmentos número que se deben generar
	 * @param registros los registros que hay que procesar
	 * @return la lista de  los segmentos generados.
	 */
	public static List<SegmentoInterface> generarSegmentos(
			int nSegmentos, List<Registro> registros) {
		System.out.println(registros.size());
		int i     = registros.size() / nSegmentos;
		//boolean resto =  (i * nSegmentos) == registros.size();

		ArrayList<SegmentoInterface> segmentos = new ArrayList<SegmentoInterface>();

		System.out.println(i);
		try {
			for (int j = 0; j < nSegmentos; j++) {
				Segmento segmento = null;
				List<Registro> aux = null; 
				if (j < nSegmentos - 1 ) {
					aux = new ArrayList<Registro>();
					for (int z = i * j; z < i* (j+1); z++) {
						aux.add(registros.get(z));
					}
					segmento = new Segmento(aux);
					segmentos.add(segmento);
				} else {
					//if (!resto) {
						aux = new ArrayList<Registro>();
						for (int z = i * j; z < registros.size(); z++) {
							aux.add(registros.get(z));
						}
						segmento = new Segmento(aux);
						segmentos.add(segmento);
					//}
				}
				
				//InvertirActores.LOGGER.finest("Se han generado un segmento"+ segmento.toString());
				
			}


		}catch(Exception E) {
			//InvertirActores.LOGGER.severe(E.toString());
		}
		//InvertirActores.LOGGER.info("Se han generado "+ segmentos.size() + " segmentos");
		return segmentos;
	}

	/**
	 * Obtener la lista de registros del segmento
	 * @return: Obtener la lista de los registros 
	 */
	public List<Registro> getRegistros() {
		return registros; 
	}


	@Override
	public String toString() {
		return null;
		//return " Tamaño: segmentos =" + cast.size() + ", movies=" + movies.size() + "]";
	}

}
