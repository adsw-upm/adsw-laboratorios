package es.upm.dit.adsw.geosocial.interfaces;

import java.util.List;

import es.upm.dit.adsw.geosocial.Registro;


/**
 * @author aalonso
 * Este interfaz modela un segmento.
 * El segmento se representa como una lista de registros.
 */


public interface SegmentoInterface {

	/**
	 * Obtener la lista de registros del segmento
	 * @return: Obtener la lista de los registros 
	 */
	List<Registro>          getRegistros();
		
}

