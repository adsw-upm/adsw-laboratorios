package es.upm.dit.adsw.geosocial.lab4;

import java.util.List;
import java.util.Map;
import java.util.Set;

import es.upm.dit.adsw.geosocial.Localizacion;
import es.upm.dit.adsw.geosocial.interfaces.ResultadoInterface;

/**
 * @author aalonso
 * Esta clase representa el resultado generado una hebra al procesar un 
 * segmento. Implementa el interfaz ResultadoInterface. El resultado está representante en un 
 * diccionarion, en el que la clave
 * es una localización y el valor es una lista de los usuarios que han estado
 * en ella.
 */
public class Resultado implements ResultadoInterface {

	private Map<Localizacion, List<Integer>> resultado;
	
	public Resultado (Map<Localizacion, List<Integer>> resultado) {
		this.resultado =resultado;
	}

	/**
	 * @author aalonso
	 * El resultado al procesar un segmento
	 * @return: El diccionario del resultado
	 */
	public Map<Localizacion, List<Integer>> getResultado(){
		return resultado;
	}
	
	@Override
	public String toString() {
		String string = "Resultado [resultado=" + resultado + "]\n";

		Set<Localizacion> set = resultado.keySet();
		for(Localizacion loc : set) {
			string = string + loc.toString() + ": \n";
			List<Integer> list = resultado.get(loc);
			for (Integer usuario : list) {
				string = string + " " + usuario;
			}
			string = string + "\n";
		}

		return string;
	}

}
