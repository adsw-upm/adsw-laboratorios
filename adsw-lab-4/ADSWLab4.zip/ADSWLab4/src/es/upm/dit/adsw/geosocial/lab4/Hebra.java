package es.upm.dit.adsw.geosocial.lab4;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import es.upm.dit.adsw.geosocial.Localizacion;
import es.upm.dit.adsw.geosocial.Registro;
import es.upm.dit.adsw.geosocial.interfaces.MonitorSegmentosInterface;
import es.upm.dit.adsw.geosocial.interfaces.ResultadoInterface;
import es.upm.dit.adsw.geosocial.interfaces.SegmentoInterface;


import java.util.HashMap;

/**
 * @author aalonso
 * Esta clase define una hebra que debe procesar segmentos. El resultado
 * es una estructura de datos que asocia una localización a los usuarios 
 * donde han estado.
 */
public class Hebra extends Thread{

	private MonitorSegmentosInterface monitor;
	private int id;

	public Hebra (MonitorSegmentosInterface monitor, int id) {
		this.monitor = monitor;
		this.id      = id;
	}

	
	/**
	 * Este método es el programa que ejecuta cada hebra
	 * 
	 * Ejecuta en un bucle para procesar los segmentos. Hay que solicitar un segmento,
	 * procesarlo y enviar el resultado. La comunicación es mediante un objeto de 
	 * MonitorSegmentos.
	 * 
	 * Al recibir un segmento hay que comprobar si ha finalizado el procesamiento
	 * de segmentos. 
	 * 
	 * Hay que comprobar si un segmento es null, para no procesarlo. 
	 *
	 */
	public void run() {
		AlmacenLab4.LOGGER.info("Inicia la hebra " + this.id);
		//TODO alumno
		// Bucle hasta que se detecta el final del monitor (método estaFinalizado)
		//   Obtener un segmento del monitor
		//   Comprobar si es nulo
		//   procesarlo (procesarSegmento)
		//   Enviar el resultado al monitor
	}

	/**
	 * Este método procesa cada segmento. 
	 * @param segmento El segmento a procesar
	 * @return El resutado al procesar el segmento
	 */
	public  ResultadoInterface procesarSegmento(SegmentoInterface segmento) {

		Map<Localizacion, List<Integer>> resultado = new HashMap<Localizacion, List<Integer>>();
		
		// Para cada registro hay que detectar los usuarios que han estado en la localización
		// Si ha actuado, incluirlo en la lista
		

		return new Resultado(resultado);
	}
}

